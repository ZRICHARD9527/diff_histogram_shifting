from dhs.handle import *

'''
1.读取图片
'''
# bob 图像具有全像素分布
img = cv2.imread('../img/input/lena.jpg', cv2.IMREAD_GRAYSCALE)
draw_hist(img, "hs pixel distribution before change")
emstr = "225114 周锐淇 网络信息隐藏\n"  # 嵌入的信息
show_pic(img, 0, "hs img before change")

'''
2.直方图平移
'''
img, ppixel, zpixel = translate(img)
draw_hist(img, "hs pixel distribution after translated")
show_pic(img, 0, "hs img after translated")

'''
3.嵌入信息
'''
n = 1
embit = encode16(emstr)  # 转换为二进制
# 前16位用来保存嵌入信息比特串的长度信息
embit = str(bin(n).replace('0b', '').zfill(16)) + str(bin(len(embit)).replace('0b', '').zfill(16)) + embit * n

print("原始信息：", emstr)
print("嵌入信息编码：", embit)
img = embed(img, embit, ppixel, zpixel)
draw_hist(img, "hs pixel distribution after embed")
show_pic(img, 0, "hs img after embed")

'''
4.提取出信息
'''
head, info, rimg = extract(img, ppixel, zpixel)
show_pic(rimg, 0, "hs img after extracted")
draw_hist(rimg, "hs pixel distribution after extracted")
print("隐藏信息编码：", info)
print("隐藏信息长度：", len(info))
print("嵌入信息解码：\n", decode16(info))
print("PSNR：", psnr(rimg, img))
