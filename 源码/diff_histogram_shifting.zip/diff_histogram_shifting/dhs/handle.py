import math

import cv2
import matplotlib.pyplot as plt
import numpy as np
import re

import skimage.util
from PIL import Image
from skimage import util, img_as_float, io


# 绘制直方图
def draw_hist(M, title):
    l_limit = min(M.ravel())  # ravel()将多维数组按照行顺序展开为一维数组
    u_limit = max(M.ravel())

    if int(l_limit) * int(u_limit) < 0:  # 异号 加上0
        seg = abs(l_limit) + u_limit + 1
    else:
        seg = u_limit - l_limit + 1  # 同号
    plt.hist(M.ravel(), int(seg), [l_limit, u_limit + 1])
    plt.xlabel("value")
    plt.ylabel("count")
    plt.title(title)
    plt.savefig("../img/output/" + title + ".jpg")
    plt.show()
    plt.clf()


# 显示图像
def show_pic(img, time, title):
    cv2.imshow(title, img)
    cv2.waitKey(time)  # 窗口延长时间
    cv2.imwrite("../img/output/" + title + ".jpg", img)
    cv2.destroyAllWindows()


def encode16(s):
    # 将字符转换为ascll码再转为16位2进制数
    # ord() 函数是 chr() 函数（对于8位的ASCII字符串）或 unichr() 函数（对于Unicode对象）的配对函数
    # 对于ascll对象返回ascll数值 对于Unicode对象返回Unicode数值
    return ''.join([bin(ord(c)).replace('0b', '').zfill(16) for c in s])


def decode16(s):
    # 每16位代表一个字符
    return ''.join([chr(i) for i in [int(b, 2) for b in re.findall(r'.{16}', s)]])


def img_bit(img):
    bitarray = str(bin(img.shape[0]).replace('0b', '').zfill(16)) + str(bin(img.shape[1]).replace('0b', '').zfill(16))
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            bitarray += bin(img[i][j]).replace('0b', '').zfill(8)
    return bitarray


def bit_img(bitarray, raw, col):
    # 先按8位分开 转为十进制数字列表 再转为数组
    img = np.array([int(b, 2) for b in re.findall(r'.{8}', bitarray)])
    img = img.reshape(raw, col)
    img = np.array(img, dtype=np.uint8)  # 将数据类型由int32转为uint8
    return img


# 像素矩阵转为二值比特串 t为阈值
def binarize(M, t=127):
    ret, mask = cv2.threshold(src=M, thresh=t, maxval=255, type=cv2.THRESH_BINARY)
    bit = ''
    for i in range(mask.shape[0]):
        for j in range(mask.shape[1]):
            if int(mask[i][j]) == 255:
                bit += '1'
            else:
                bit += '0'
    return bit


# 将二值串解析成像素矩阵
def unbinarize(s, raw, col):
    arr = np.zeros(raw * col)
    for i in range(len(s)):
        # print("s[", i, "]", s[i])
        if s[i] == '0':
            arr[i] = 0
        elif s[i] == '1':
            arr[i] = 255
    M = np.array(arr.reshape((raw, col)), dtype=np.uint8)
    return M


# 直方图移动
def translate(M):
    # uint8 与 int32 运算会自动转换为int32
    l_limit = min(M.ravel())  # ravel()将多维数组按照行顺序展开为一维数组
    u_limit = max(M.ravel())

    if int(l_limit) * int(u_limit) < 0:  # 异号 加上0
        seg = abs(l_limit) + u_limit + 1
    else:
        seg = u_limit - l_limit + 1  # 同号

    # count 返回 每个bin里元素的数量；bins 返回每个bin的区间范围；patches返回每个bin里面包含的数据，是一个list
    count, bins, patches = plt.hist(M.ravel(), bins=int(seg), range=[l_limit, u_limit + 1])
    # 分别为最小频数、对应的值大小
    zp, z_value = min(count), bins[np.argmin(count)]
    # 分别为最大频数、对应的值大小
    pp, p_value = max(count), bins[np.argmax(count)]
    print("最小频数：", zp, "\t值：", z_value)
    print("最大频数：", pp, "\t值：", p_value)

    if z_value > p_value:
        flag = 1
    else:
        flag = -1

    # 平移直方图
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if (M[i][j] - z_value) * (M[i][j] - p_value) < 0:  # 说明在zp与pp之间
                M[i][j] += flag

    return M, p_value, z_value


# 嵌入信息
def embed(M, embit, p_value, z_value):
    if z_value > p_value:
        flag = 1
    else:
        flag = -1

    bitlen = len(embit)
    print("嵌入编码长度：", bitlen)
    # 信息嵌入
    k = 0
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            # 像素值为p_value时 若嵌入信息为1则img[i][j]+flag 为0不变
            if (M[i][j] == p_value) and (k < bitlen):
                M[i][j] = M[i][j] + flag * int(embit[k])
                k += 1
    return M


# 从M中提取嵌入的信息，并恢复M
def extract(M, p_value, z_value):
    if z_value > p_value:
        flag = 1
    else:
        flag = -1
    bitarray = ''
    # 提取嵌入信息，并复原图像
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if M[i][j] == p_value:
                bitarray += '0'
            elif M[i][j] == p_value + flag:
                M[i][j] -= flag
                bitarray += '1'
            elif (M[i][j] - p_value - flag) * (M[i][j] - z_value - flag) < 0:
                # 将像素值位于 p_value+flag 与 z_value+flag之间（不包括端点）的像素平移回去
                M[i][j] -= flag

    # 实际嵌入比特串的长度
    # 前32位用于存储嵌入信息本身的信息
    # 若为文本信息 n1为重复次数 n2为信息bit长度
    # 若为图像信息 n1为行数 n2为列数
    # bitarray 为嵌入信息本身
    head = bitarray[0:32]
    bitarray = bitarray[32:32 + int(head[:16], 2) * int(head[16:32], 2)]

    return head, bitarray, M


# 从差值矩阵中提取嵌入后的信息以及恢复原图
def extract_diff(M, p_value, z_value):
    # 1.计算得到(嵌入数据后的)差值矩阵
    D = np.zeros((M.shape[0], int(M.shape[1] / 2)))
    for i in range(M.shape[0]):
        for j in range(int(M.shape[1] / 2)):
            D[i][j] = abs(int(M[i][2 * j + 1]) - int(M[i][2 * j]))
    # 2.提取信息 返回嵌入信息与初始差值矩阵
    head, bitarray, real_D = extract(D, p_value, z_value)

    # 3.复原图像，由于奇数列没有变化 由奇数列与差值矩阵可以得到原始图像
    M = insertD(M, real_D)

    return head, bitarray, M


# 将差值矩阵添加进原矩阵
def insertD(M, D):
    for i in range(D.shape[0]):
        for j in range(D.shape[1]):
            if M[i][2 * j + 1] > M[i][2 * j]:
                M[i][2 * j + 1] = M[i][2 * j] + D[i][j]
            else:
                M[i][2 * j + 1] = M[i][2 * j] - D[i][j]
    return M


# 高斯白噪声 M为图像矩阵 arg为方差参数
def g_noise(M, arg):
    return skimage.util.random_noise(M, mode='gaussian', var=arg)


# 椒盐噪声
def s_noise(M, arg):
    return skimage.util.random_noise(M, mode='s&p', amount=arg)


def psnr(img1, img2):
    mse = np.mean((img1 / 1.0 - img2 / 1.0) ** 2)
    if mse < 1e-10:
        return 100
    else:
        p = 20 * math.log10(255 / math.sqrt(mse))
        return p


# 归一化系数 比较原载体图像与提取信息后恢复的图像之间的相似度
def nc(img1, img2):
    n = 0
    d1 = math.sqrt(np.sum(img1 ** 2))
    d2 = math.sqrt(np.sum(img2 ** 2))
    print(d1, d2)
    for i in range(img1.shape[0]):
        for j in range(img1.shape[1]):
            # print(img1[i][j], img2[i][j])
            # print(n, (img1[i][j] / d1), (img2[i][j] / d2))
            n += (img1[i][j] / d1) * (img2[i][j] / d2)
    return n

# # 读入图像
# img = cv2.imread("../img/input/info2.jpg", cv2.IMREAD_GRAYSCALE)
# img2 = np.array(img)
#
# print(nc(img, img2))
# print(psnr(img, img2))

# # 嵌入行列信息
# bitarray = str(bin(img.shape[0]).replace('0b', '').zfill(16)) + str(bin(img.shape[1]).replace('0b', '').zfill(16))
# # 图像转换为二值比特串
# mask = bitarray + binarize(img)
# raw = int(mask[:16], 2)
# col = int(mask[16:32], 2)
# print("raw:", raw, "\tcol:", col)
# # print(mask)
# print(len(mask))
# M = unbinarize(mask[32:], raw, col)
# print(M.shape)
# print(M.dtype)
#
# show_pic(M, 0, "extract info")
