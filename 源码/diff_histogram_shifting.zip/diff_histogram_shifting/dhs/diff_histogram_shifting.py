import cv2
import numpy as np

from dhs.handle import *

'''
1.读取图像
'''
img = cv2.imread('../img/input/lena.jpg', cv2.IMREAD_GRAYSCALE)
draw_hist(img, "dhs pixel distribution")
show_pic(img, 1, "dhs img before change")

'''
2.构建像素差值矩阵 shape： nx(m-1)
'''
D = np.zeros((img.shape[0], int(img.shape[1] / 2)))
# 图像像素值是ubyte类型 占8位，数据范围为0~255
# 若做运算出现负值或超出255，则会抛出异常，进行取模运算。可以强制转换为int
for i in range(img.shape[0]):
    for j in range(int(img.shape[1] / 2)):
        D[i][j] = abs(int(img[i][2 * j + 1]) - int(img[i][2 * j]))
draw_hist(D, "dhs D-value distribution before change")

'''
3.差值直方图平移
'''
D, p_value, z_value = translate(D)
draw_hist(D, "dhs D-value distribution after translated")

'''
4.嵌入信息
'''
# 读取嵌入图像
em_img = cv2.imread("../img/input/info2.jpg", cv2.IMREAD_GRAYSCALE)
# 嵌入数据头 包含嵌入图像的行、列数
em_head = str(bin(em_img.shape[0]).replace('0b', '').zfill(16)) + str(bin(em_img.shape[1]).replace('0b', '').zfill(16))
# 数据头加上二值化的图像编码
em_bit = em_head + binarize(em_img)
# 获取嵌入后的差值矩阵
D = embed(D, em_bit, p_value, z_value)
draw_hist(D, "dhs D-value distribution after embed")

'''
5.将嵌入后的差值矩阵合并到图像中
'''
eimg = insertD(img, D)

d = np.array(eimg)
print("eimg 未改变：", (eimg == d).all())

draw_hist(eimg, "dhs pixel distribution after embed")
show_pic(eimg, 1, "dhs img after embed")

'''
6.提取嵌入信息
'''
head, bits, rimg = extract_diff(eimg, p_value, z_value)
info = unbinarize(bits, int(head[0:16], 2), int(head[16:32], 2))
print(info.shape)
show_pic(rimg, 1, "dhs img after extracted")
show_pic(info, 1, "dhs img extract info")
draw_hist(rimg, "dhs pixel distribution after extracted")

print("提取后的图像与原图psnr：", psnr(rimg, img))
print("嵌入信息 psnr：", psnr(em_img, info))


'''
测试图像
'''

# 高斯噪声
print("eimg 未改变：", (eimg == d).all())

arg = np.array([0.001, 0.01, 0.1, 1])
for i in range(arg.shape[0]):
    noise = g_noise(d, arg[i])
    noise_img = noise + d
    cv2.imshow("g_noise", noise)
    cv2.waitKey(1)

    thead, tbits, test = extract_diff(noise_img, p_value, z_value)
    tinfo = unbinarize(bits[:78 * 177], int(head[0:16], 2), int(head[16:32], 2))

    show_pic(tinfo, 1, "test info img g_noise" + str(arg[i]))
    draw_hist(test, "test dhs pixel distribution after extracted " + str(arg[i]))

    '''评价指标'''
    # 求每次的psnr
    print(str(arg[i]) + "psnr值:", psnr(em_img, tinfo), "\t提取后的图像与载体psnr：", psnr(test, img))

# 椒盐噪声
arg1 = np.array([0.001, 0.01, 0.03, 0.05])
for i in range(arg1.shape[0]):
    sp_noise = s_noise(d, arg1[i])
    cv2.imshow("s_noise", sp_noise)
    cv2.waitKey(1)

    noise_img = d + sp_noise

    thead, tbits, test = extract_diff(noise_img, p_value, z_value)
    tinfo = unbinarize(tbits[:78 * 177], int(head[0:16], 2), int(head[16:32], 2))
    show_pic(tinfo, 1, "test info img sp_noise" + str(arg1[i]))
    p = psnr(em_img, tinfo)
    print(str(arg1[i]) + "psnr值:", p, "\t提取后的图像与载体psnr：", psnr(test, img))
